const url = 'process.php';
const form = document.querySelector('form');

form.addEventListener('submit', e => {
    e.preventDefault();
	
	//document.getElementById('rst').innerHTML('Verify something wrong!!!');
    const files = document.querySelector('[type=file]').files;	
    const formData = new FormData();
    for (let i = 0; i < files.length; i++) {
        let file = files[i];
        formData.append('files[]', file);
    }

    fetch( url, {
			method: 'POST',
			body: formData
    	}).then( response => {
        	console.log(response);		
    });
	
	//	*********************************
	var nFile = document.getElementById('nFile').files;
	if (!nFile.length) {
	  alert('Please select a file!');
	  return;
	}

	var upFile = nFile[0];

	var reader = new FileReader();
	var stop = upFile.size - 1;

	// If we use onloadend, we need to check the readyState.
	reader.onloadend = function(evt) {
		if (evt.target.readyState == FileReader.DONE) { // DONE == 2
			//document.getElementById('rst').textContent = "<pre> <code>" + evt.target.result + "</code> </pre>";
			document.getElementById('rst').innerHTML = "<pre> <code>" + evt.target.result + "</code> </pre>";
		}
	};
	var blob = upFile.slice(0, stop + 1);
	reader.readAsBinaryString(blob);
});

